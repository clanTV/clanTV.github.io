//本代码仅用于个人学习，请勿用于其他作用，下载后请24小时内删除
function SRCSet() {
    addListener("onClose", $.toString(() => {
        clearMyVar('guanlicz');
        //refreshPage(false);
    }));
    setPageTitle("♥管理"+getVar('SrcJuying-Version', ''));
    function jiekouchuli(lx,urls) {
        function apitype(apiurl) {
            if(apiurl){
                if(apiurl.includes('.vod')){
                    return "v1";
                }else if(apiurl.includes('/app/')){
                    return "app";
                }else if(apiurl.includes('app.php')){
                    return "v2";
                }else if(/iptv|Chengcheng/.test(apiurl)){
                    return "iptv";
                }else if(apiurl.includes('provide/vod/')){
                    return "cms";
                }else{
                    return "";
                }
            }else{
                return "";
            }
        }
        if(lx=="type"){
            return apitype(urls);
        }else if(lx=="save"){
            try{
                var filepath = "hiker://files/rules/Src/Juying/jiekou.json";
                var datafile = fetch(filepath);
                if(datafile != ""){
                    eval("var datalist=" + datafile+ ";");
                }else{
                    var datalist = [];
                }
                
                var num = 0;
                for (var i in urls) {
                    let urlname = urls[i].name;
                    let urlurl = urls[i].url;
                    let urlua = urls[i].ua||"Dalvik/2.1.0";
                    let urltype = urls[i].type||apitype(urlurl);
                    let urlgroup = urls[i].group||"";
                    if(!datalist.some(item => item.url ==urlurl)&&urlname&&/^http/.test(urlurl)&&urltype){
                        let arr  = { "name": urlname, "url": urlurl, "ua": urlua, "type": urltype, "group": urlgroup };
                        datalist.push(arr);
                        num = num + 1;
                    }
                }
                if(num>0){writeFile(filepath, JSON.stringify(datalist));}
            } catch (e) {
                log('导入失败：'+e.message); 
                return -1;
            }
            return num;
        }else{
            return "toast://接口处理类型不正确";
        }
    }
    function getTitle(title, Color) {
        return '<font color="' + Color + '">' + title + '</font>';
    }
    var d = [];
    d.push({
        title: getMyVar('guanli', 'jk')=="jk"?getTitle('接口管理', '#f13b66a'):'接口管理',
        url: `#noLoading#@lazyRule=.js:putMyVar('guanli','jk');refreshPage(false);'toast://已切换到接口管理';`,
        img: "https://lanmeiguojiang.com/tubiao/movie/98.svg",
        col_type: "icon_small_3"
    });
    d.push({
        title: getMyVar('guanli', 'jk')=="jk"?'解析管理':getTitle('解析管理', '#f13b66a'),
        url: `#noLoading#@lazyRule=.js:putMyVar('guanli','jx');refreshPage(false);'toast://已切换到解析管理';`,
 